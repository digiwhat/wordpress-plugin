<?php
/**
 * Plugin Name:       DigiWhat Plugin
 * Plugin URI:        https://digiwhat.de/
 * Description:       Include DigiWhat into your wordpress site. Add the shortcode [digiwhat realm="your_realm"]
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            
 * Author URI:        
 * License:           UNLICENSED
 * License URI:       
 * Update URI:        
 * Text Domain:       digiwhat-plugin
 * Domain Path:       /languages
 * 
 * Todo: add Widget for it like in https://www.wpexplorer.com/create-widget-plugin-wordpress/
 */

 /**
 * 
 * The [digiwhat] shortcode.
 *
 * Accepts some parameters and will embed digiwhat.
 *
 * @param array  $atts    Shortcode attributes. Default empty.
 * @param string $content Shortcode content. Default null.
 * @param string $tag     Shortcode tag (name). Default empty.
 * @return string Shortcode output.
 */
function digiwhat_shortcode( $atts = [], $content = null, $tag = '' ) {
    global $wp;

    $urlHost = parse_url($_SERVER['HTTP_HOST'], PHP_URL_HOST);

    $scriptUrl = array(
      "dev" => "http://$urlHost:3000/static/js/digiwhat-services.js",
      "staging" => "https://stage.digiwhat.de/viewer/static/js/digiwhat-services.js",
      "production" => "https://digiwhat.de/viewer/static/js/digiwhat-services.js"
    );

    $cssUrl = array(
      "dev" => "http://$urlHost:3000/static/css/digiwhat-services.css",
      "staging" => "https://stage.digiwhat.de/viewer/static/css/digiwhat-services.css",
      "production" => "https://digiwhat.de/viewer/static/css/digiwhat-services.css"
    );

    // normalize attribute keys, lowercase
    $atts = array_change_key_case( (array) $atts, CASE_LOWER );
 
    // override default attributes with user attributes
    $digiwhat_atts = shortcode_atts(
        array(
            'realm' => 'digiwhat',
            'canonicalUrl' => add_query_arg( $wp->query_vars, home_url( $wp->request ) ),
            'environment' => 'production'
        ), $atts, $tag
    );

    $realm = $digiwhat_atts['realm'];
    $canonicalUrl = $digiwhat_atts['canonicalUrl'];
    $environment = $digiwhat_atts['environment'];
    
    $script = array_key_exists($environment, $scriptUrl)? $scriptUrl[$environment] : $scriptUrl["production"];
    $css = array_key_exists($environment, $cssUrl)? $cssUrl[$environment] : $cssUrl["production"];

    $content = <<<SCR
                  <link rel="stylesheet" id="digiwhat-style-css" href="$css" media="all">
                  <script src="$script"></script>
                  <script crossorigin>
                      DigiWhatInterface.config({
                        realm: '$realm',
                        canonicalUrl: '$canonicalUrl',
                        environment: '$environment'
                      });
                      var useCasesInplaceWidget = DigiWhatInterface.widgets.useCasesInplace.create({
                        selector: "#digiwhat-use-cases-inplace",
                        filter: false,
                      });
                      useCasesInplaceWidget.render();
                    </script>
                SCR;

    // return output
    return "<div id=\"digiwhat-use-cases-inplace\"></div>\n$content";
}

/**
 * Central location to create all shortcodes.
 */
function digiwhat_shortcodes_init() {
    add_shortcode( 'digiwhat', 'digiwhat_shortcode' );
}
 
add_action( 'init', 'digiwhat_shortcodes_init' );
